package com.security.demo.controllers;

import com.security.demo.repository.BookServiceRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("api")
public class RestController {
  @Autowired
  BookServiceRepo bookServiceRepo;

  @GetMapping("resource1")
  public String returnResource1(){
    return "this is resource 111111";
  }

  @GetMapping("resource2")
  public String returnResource2(){
    return "this is resource 2222222";
  }

  @GetMapping("get-book")
  public String getBookName(@RequestParam("bookName") String bookName){
    return bookServiceRepo.findBookByName(bookName);
  }
}
