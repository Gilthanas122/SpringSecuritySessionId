package com.security.demo.repository;

import com.security.demo.exceptions.BookNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BookServiceRepo {
  private List<String> bookNames;

  public BookServiceRepo() {
    this.bookNames = new ArrayList<>();
    this.bookNames.add("Harry Potter 1");
    this.bookNames.add("Harry Potter 2");
    this.bookNames.add("Lord of the Rings");
  }

  public String findBookByName(String bookName){
    if (!bookNames.contains(bookName)){
      throw new BookNotFoundException(bookName);
    }else{
      int indexOfBook = bookNames.indexOf(bookName);
      return bookNames.get(indexOfBook);
    }
  }
}
